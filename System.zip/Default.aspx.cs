﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Master
{
    public partial class Default : System.Web.UI.Page
    {
        App_Code.connect connect = new App_Code.connect();
        public string chuoibang = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            DataTable dt = connect.Querry("select * from listcode");
            if(dt.Rows.Count>0)
            {
                for(int i=0;i<dt.Rows.Count;i++)
                {
                    chuoibang += "<tr>" +
                                "<td>" + dt.Rows[i]["id"].ToString() + "</td>" +
                                "<td>" + dt.Rows[i]["code"].ToString() + "</td>" +
                                "<td>" + dt.Rows[i]["name"].ToString() + "</td>";
                }    
            }    

        }
    }
}