﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Master.Approval.Public
{
    public partial class Mounter : System.Web.UI.Page
    {
        App_Code.connect connect = new App_Code.connect();
        public string dtdgv = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            DataTable dt = connect.Querry("select * from MasterNameSMT where Line = '1' and IDForm = 'F007' and RequestNo='2024020001';");
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dtdgv += @"<tr>
                        <td>" + (i+1).ToString() + @"</td>
                        <td>" + dt.Rows[i]["Line"].ToString() + @"</td>
                        <td>" + dt.Rows[i]["Unit"].ToString() + @"</td>
                        <td>" + dt.Rows[i]["Mat"].ToString() + @"</td>
                        <td>" + dt.Rows[i]["NameProgram"].ToString() + @"</td>
                      </tr> ";
                }
            }




        }
    }
}