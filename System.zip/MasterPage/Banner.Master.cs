﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Master.MasterPage
{
    public partial class Banner : System.Web.UI.MasterPage
    {
        public string hienthi = "";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnclick(object sender, EventArgs e)
        {
            hienthi = @"        <div class=""notifications"">
            <div id=""toastAutoHide"" class=""toast fade hide"" role=""alert"" aria-live=""assertive"" aria-atomic=""true"" data-bs-delay=""4000"">
                <div class=""toast-header"">
                    <span class=""d-block bg-warning rounded me-2"" style=""width: 20px; height: 20px;""></span>
                    <strong class=""me-auto"">Hệ thống</strong>
                    <small>1s trước</small>
                </div>
                <div class=""toast-body"">
                Lỗi rồi bạn ơi
                </div>
            </div>
        </div>
        <script>
            window.addEventListener('load', () => {
                document.querySelectorAll('.toast').forEach(toastEl => new bootstrap.Toast(toastEl))
                document.querySelectorAll('.toast').forEach(toastEl => bootstrap.Toast.getInstance(toastEl).show())
            })
        </script>";
        }


        protected void Button1_Click(object sender, EventArgs e)
        {

        }
    }
}