﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Master.Models
{
    public class UsersModel
    {
        public string UserName { get; set; }
    }
}